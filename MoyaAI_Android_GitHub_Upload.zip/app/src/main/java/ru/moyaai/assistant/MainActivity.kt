package ru.moyaai.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(val role: String, val content: String)
data class MediaAttachment(val uri: Uri, val mime: String, val label: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AssistantScreen(applicationContext) } }
    }
}

@Composable
fun AssistantScreen(context: Context) {
    val prefs = remember { context.getSharedPreferences("moya_ai", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions") ?: "") }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gpt-4o-mini") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var offlineStatus by remember { mutableStateOf("Локальная языковая модель не установлена") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var memoryText by remember { mutableStateOf(prefs.getString("memory", "") ?: "") }
    var showMemory by remember { mutableStateOf(false) }
    var attachment by remember { mutableStateOf<MediaAttachment?>(null) }
    var notice by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) attachment = MediaAttachment(uri, "image", "Изображение")
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) attachment = MediaAttachment(uri, "video", "Видео")
    }

    val messages = remember {
        mutableStateListOf<ChatMessage>().apply {
            val raw = prefs.getString("history", "[]") ?: "[]"
            runCatching {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(ChatMessage(o.optString("role"), o.optString("content")))
                }
            }
        }
    }

    fun persist() {
        val arr = JSONArray()
        messages.takeLast(80).forEach { m -> arr.put(JSONObject().put("role", m.role).put("content", m.content)) }
        prefs.edit().putString("history", arr.toString()).putString("memory", memoryText).apply()
    }

    fun learnFrom(text: String) {
        val trimmed = text.trim()
        val lower = trimmed.lowercase()
        val candidate = when {
            lower.startsWith("запомни:") -> trimmed.substringAfter(":").trim()
            lower.startsWith("запомни ") -> trimmed.substringAfter(" ", "").trim()
            lower.startsWith("меня зовут ") -> "Пользователя зовут " + trimmed.substringAfter("меня зовут ", "")
            lower.startsWith("я предпочитаю ") -> "Предпочтение пользователя: " + trimmed.substringAfter("я предпочитаю ", "")
            else -> ""
        }
        if (candidate.isNotBlank() && !memoryText.lines().any { it.equals(candidate, true) }) {
            memoryText = (memoryText.lines().filter { it.isNotBlank() } + candidate).takeLast(100).joinToString("\n")
            prefs.edit().putString("memory", memoryText).apply()
        }
    }

    suspend fun bitmapDataUrl(uri: Uri): String = withContext(Dispatchers.IO) {
        val original = context.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
            ?: throw IllegalArgumentException("Не удалось прочитать изображение")
        val maxSide = 1024
        val scale = minOf(1f, maxSide.toFloat() / maxOf(original.width, original.height))
        val bitmap = if (scale < 1f) Bitmap.createScaledBitmap(original, (original.width * scale).toInt().coerceAtLeast(1), (original.height * scale).toInt().coerceAtLeast(1), true) else original
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
        if (bitmap !== original) bitmap.recycle()
        original.recycle()
        "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun videoFrameDataUrls(uri: Uri): List<String> = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        val frames = mutableListOf<String>()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (durationMs <= 0L) throw IllegalArgumentException("Не удалось прочитать длительность видео")
            // Sample at most 5 frames across the clip to keep request size reasonable.
            val count = minOf(5, maxOf(1, ((durationMs / 1000) / 5).toInt() + 1))
            for (i in 0 until count) {
                val timeMs = if (count == 1) 0L else (durationMs - 1) * i / (count - 1)
                val bmp = retriever.getFrameAtTime(timeMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                val scale = minOf(1f, 768f / maxOf(bmp.width, bmp.height))
                val small = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true) else bmp
                val out = ByteArrayOutputStream()
                small.compress(Bitmap.CompressFormat.JPEG, 75, out)
                frames.add("data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
                if (small !== bmp) small.recycle()
                bmp.recycle()
            }
        } finally { retriever.release() }
        if (frames.isEmpty()) throw IllegalArgumentException("Не удалось извлечь кадры из видео")
        frames
    }

    suspend fun askOnline(userText: String, media: MediaAttachment?): String = withContext(Dispatchers.IO) {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection)
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (apiKey.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer $apiKey")
            val apiMessages = JSONArray()
            apiMessages.put(JSONObject().put("role", "system").put("content",
                "Ты — Моя AI, помощник на русском языке. Используй локальную память как контекст; не выдумывай факты.\nПамять пользователя:\n${memoryText.take(6000)}"))
            messages.takeLast(16).forEach { m -> apiMessages.put(JSONObject().put("role", m.role).put("content", m.content)) }

            val userContent: Any = if (media == null) userText else {
                val parts = JSONArray()
                parts.put(JSONObject().put("type", "text").put("text",
                    (if (userText.isBlank()) "Проанализируй прикреплённый материал и опиши, что видишь." else userText) +
                    if (media.mime == "video") "\nЭто видео. Проанализируй доступные кадры по порядку; движение между кадрами может быть не показано." else ""))
                val images = if (media.mime == "video") videoFrameDataUrls(media.uri) else listOf(bitmapDataUrl(media.uri))
                images.forEach { dataUrl ->
                    parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", dataUrl).put("detail", "low")))
                }
                parts
            }
            apiMessages.put(JSONObject().put("role", "user").put("content", userContent))
            val body = JSONObject().put("model", model).put("messages", apiMessages).put("temperature", 0.7)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code: ${response.take(300)}")
            JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } finally { conn.disconnect() }
    }

    fun offlineReply(text: String): String {
        val lower = text.trim().lowercase()
        return when {
            lower.startsWith("запомни") -> "Я сохранила это в локальную память. Нажми «Память», чтобы посмотреть или изменить её."
            lower.contains("что ты помнишь") || lower.contains("моя память") ->
                if (memoryText.isBlank()) "Пока память пустая. Напиши: «Запомни: я предпочитаю короткие ответы»."
                else "Вот что сохранено локально:\n$memoryText"
            lower.contains("привет") -> "Привет! Я Моя AI. История и память доступны офлайн, но анализ изображений/видео требует подключённой онлайн-модели с поддержкой vision."
            else -> "Сейчас онлайн-модель недоступна. История и память сохраняются на телефоне, но полноценная офлайн-нейросеть в этой версии не встроена. Для анализа медиа подключи vision-модель в настройках."
        }
    }

    fun send() {
        if ((input.isBlank() && attachment == null) || busy) return
        val sent = input.trim()
        val media = attachment
        val displayText = sent.ifBlank { "Проанализируй ${media?.label?.lowercase() ?: "вложение"}." }
        input = ""
        attachment = null
        notice = ""
        learnFrom(sent)
        messages.add(ChatMessage("user", displayText + if (media != null) " [${media.label} прикреплено]" else ""))
        persist()
        scope.launch {
            busy = true
            val reply = try {
                if (endpoint.isNotBlank() && apiKey.isNotBlank()) askOnline(sent, media)
                else if (media != null) "Чтобы анализировать фото или видео, подключи в ⚙ онлайн API с поддержкой анализа изображений. Файл не отправлялся."
                else offlineReply(sent)
            } catch (e: Exception) {
                "Не удалось получить ответ: ${e.message ?: "ошибка сети"}\nПроверь API, ключ и поддержку изображений выбранной моделью."
            }
            messages.add(ChatMessage("assistant", reply))
            persist()
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("Моя AI", style = MaterialTheme.typography.headlineMedium)
                Text(if (endpoint.isNotBlank() && apiKey.isNotBlank()) "Онлайн API · локальная память" else "Локальный режим · память включена", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { showMemory = true }) { Text("Память") }
            TextButton(onClick = { showSettings = true }) { Text("⚙") }
        }
        Divider()
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (messages.isEmpty()) item {
                Text("Привет! Я Моя AI.\n\nПрикрепляй фото или видео кнопками ниже. Анализ медиа работает через онлайн vision-модель. Напиши «Запомни: …», чтобы сохранить факт.", modifier = Modifier.padding(8.dp))
            }
            items(messages) { m ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (m.role == "user") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(if (m.role == "user") "Ты" else "Моя AI", style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(m.content)
                    }
                }
            }
            if (busy) item { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(24.dp)); Spacer(Modifier.width(8.dp)); Text("Анализирую…") } }
        }
        if (attachment != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Вложение: ${attachment!!.label}", modifier = Modifier.weight(1f))
                TextButton(onClick = { attachment = null }) { Text("Убрать") }
            }
        }
        if (notice.isNotBlank()) Text(notice, color = MaterialTheme.colorScheme.error)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = { imagePicker.launch("image/*") }, enabled = !busy) { Text("Фото") }
            TextButton(onClick = { videoPicker.launch("video/*") }, enabled = !busy) { Text("Видео") }
        }
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Напиши сообщение…") }, maxLines = 5,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Button(enabled = (input.isNotBlank() || attachment != null) && !busy, onClick = { send() }) { Text("➤") }
        }
    }

    if (showSettings) AlertDialog(
        onDismissRequest = { showSettings = false },
        title = { Text("Подключение нейросети") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Нужен совместимый Chat Completions API. Для анализа фото/видео выбери модель с поддержкой изображений. Запросы и вложения отправляются выбранному провайдеру.")
                Text("Офлайн-модель: $offlineStatus")
                Text("В этой сборке подключён ONNX Runtime, но автоматическая загрузка и полноценная генерация локальной LLM ещё не реализованы. Не загружай случайные файлы модели.")
                OutlinedTextField(endpoint, { endpoint = it }, label = { Text("URL API") }, singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Название модели") }, singleLine = true)
                OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API-ключ") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = {
            prefs.edit().putString("endpoint", endpoint.trim()).putString("model", model.trim()).putString("api_key", apiKey.trim()).apply()
            showSettings = false
        }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Отмена") } }
    )

    if (showMemory) AlertDialog(
        onDismissRequest = { showMemory = false },
        title = { Text("Локальная память") },
        text = {
            Column {
                Text("Заметки хранятся на телефоне и используются как контекст онлайн-ответов. Это персонализация, а не переобучение весов модели.")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(memoryText, { memoryText = it }, label = { Text("Факты и предпочтения") }, minLines = 5, maxLines = 10)
            }
        },
        confirmButton = { TextButton(onClick = { prefs.edit().putString("memory", memoryText).apply(); showMemory = false }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = { memoryText = ""; prefs.edit().putString("memory", "").apply(); showMemory = false }) { Text("Очистить память") } }
    )
}
