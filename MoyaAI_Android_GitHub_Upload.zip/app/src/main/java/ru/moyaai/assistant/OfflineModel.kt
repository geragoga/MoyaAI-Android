package ru.moyaai.assistant

import android.content.Context
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.File

/**
 * Minimal ONNX runtime integration scaffold.
 *
 * A real LLM requires a model-specific tokenizer and generation loop. This scaffold
 * validates that a local ONNX model can be loaded; it intentionally does not claim
 * arbitrary GGUF/ONNX models are directly chat-compatible.
 */
class OfflineModel(private val context: Context) {
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var session: OrtSession? = null

    fun modelFile(): File = File(context.filesDir, "offline-model/model.onnx")

    fun isInstalled(): Boolean = modelFile().exists() && modelFile().length() > 0

    fun load(): String {
        val file = modelFile()
        if (!file.exists()) return "Офлайн-модель не установлена. Поместите совместимую ONNX-модель в ${file.absolutePath}"
        return try {
            session?.close()
            session = env.createSession(file.absolutePath, OrtSession.SessionOptions())
            "ONNX-модель загружена, но для генерации текста нужен совместимый токенизатор и адаптер конкретной модели."
        } catch (e: Exception) {
            "Не удалось загрузить ONNX-модель: ${e.message}"
        }
    }

    fun close() {
        session?.close()
        session = null
    }
}
